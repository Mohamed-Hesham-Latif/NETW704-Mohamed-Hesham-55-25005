
package com.example.ms000000000

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class Map : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var Map2: GoogleMap


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }
    override fun onMapReady(googleMap: GoogleMap) {
        Map2 = googleMap

        val guc_clinic = LatLng(30.0277, 31.4955)

        val drugstore = LatLng(30.0309, 31.4913)

        Map2.addMarker(MarkerOptions().position(guc_clinic).title("guc_clinic"))

        Map2.moveCamera(CameraUpdateFactory.newLatLng(guc_clinic))

        Map2.addMarker(MarkerOptions().position(drugstore).title("drugstore"))

        Map2.moveCamera(CameraUpdateFactory.newLatLng(drugstore))
    }
}
