package com.example.ms000000000

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button


class MapOrInfo : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map_or_info)

        val userinfo = findViewById<Button>(R.id.userinfo)
        val mapbutton = findViewById<Button>(R.id.mapbutton)

        mapbutton.setOnClickListener {
            val mapIntent = Intent(this, Map::class.java)
            startActivity(mapIntent)
        }

        userinfo.setOnClickListener {
            val intent = Intent(this, UserInfo::class.java)
            startActivity(intent)
        }


    }
}
