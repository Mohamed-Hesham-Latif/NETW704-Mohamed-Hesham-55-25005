package com.example.ms000000000

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class Register : AppCompatActivity() {
    private lateinit var signup2: Button
    private lateinit var name2: EditText
    private lateinit var mail2: EditText
    private lateinit var password2: EditText
    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)


        mail2 = findViewById(R.id.mail2)
        name2 = findViewById(R.id.name2)
        password2 = findViewById(R.id.password2)
        mAuth = FirebaseAuth.getInstance()
        signup2 = findViewById(R.id.signup2)

        signup2.setOnClickListener {
            val name2 = name2.text.toString()
            val mail2 = mail2.text.toString()
            val password2 = password2.text.toString()

            if (name2.isNotEmpty() && mail2.isNotEmpty() && password2.isNotEmpty()) {
                if (password2.length >= 6) {
                    signup(mail2, password2)
                } else {
                    Toast.makeText(this, "Password has to be 6 characters", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Fill in the fields", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun signup(email: String, password: String) {

        mAuth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val intent = Intent(this@Register, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this@Register, "error", Toast.LENGTH_SHORT).show()
                }
            }
    }

}
