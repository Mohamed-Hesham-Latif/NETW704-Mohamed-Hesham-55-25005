package com.example.ms000000000

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class SignIn : AppCompatActivity() {

    private lateinit var emailtext: EditText
    private lateinit var loginbutton: Button
    private lateinit var registerbutton: Button
    private lateinit var passwordtext: EditText
    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in)

        mAuth = FirebaseAuth.getInstance()
        registerbutton = findViewById(R.id.registerbutton)
        emailtext = findViewById(R.id.emailtext)
        loginbutton = findViewById(R.id.loginbutton)
        passwordtext = findViewById(R.id.passwordtext)


        loginbutton.setOnClickListener {
            val email = emailtext.text.toString()
            val password = passwordtext.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                login(email, password)
            } else {
                Toast.makeText(this, "fill in what is missing", Toast.LENGTH_LONG).show()
            }
        }
        registerbutton.setOnClickListener {
            val intent = Intent(this, Register::class.java)
            startActivity(intent)
        }
    }

    private fun login(email: String, password: String) {
        mAuth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val intent = Intent(this@SignIn, MapOrInfo::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    task.exception?.message?.let {
                        Toast.makeText(this, "try again", Toast.LENGTH_LONG).show()
                    }
                }
            }
    }


}
