package com.example.ms000000000

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest

class UserInfo : AppCompatActivity() {

    private lateinit var usercredentials: TextView
    private lateinit var editname: EditText
    private lateinit var mAuth: FirebaseAuth
    private lateinit var updatebutton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_info)

        usercredentials = findViewById(R.id.usercredentials)
        editname = findViewById(R.id.editname)
        updatebutton = findViewById(R.id.updatebutton)
        mAuth = FirebaseAuth.getInstance()

        val currentUser = mAuth.currentUser
        if (currentUser != null) {
            val email = currentUser.email

            val displayName = currentUser.displayName ?: "No name"

            usercredentials.text = "Email: $email\nDisplay Name: $displayName"
        } else {
            usercredentials.text = "No user signed in."
        }

        updatebutton.setOnClickListener {

            val newDisplayName = editname.text.toString()

            if (newDisplayName.isNotEmpty()) {
                val user = mAuth.currentUser
                user?.let {
                    val profileUpdates = UserProfileChangeRequest.Builder()
                        .setDisplayName(newDisplayName)
                        .build()

                    user.updateProfile(profileUpdates)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                usercredentials.text = "Email: ${user.email}\nDisplay Name: $newDisplayName"
                                Toast.makeText(this, "name updated", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this, "Failed to update display name", Toast.LENGTH_SHORT).show()
                            }
                        }
                }
            } else {
                Toast.makeText(this, "enter a name please", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
